# CoCarry: Workflow + Multi-Agent Orchestration Learnings (Seed)
UTC: 20260127T041014Z
SESSION: CoSources
CLASSIFICATION: HOLD (default until explicitly classified)

## Summary
Seed-stage capsule for running multi-agent + tool workflows with fail-closed receipts and minimal human friction.

## Coordination tax + negative-returns regimes
- Where adding agents/tools increases overhead faster than throughput.
- Watch for: duplicated work, partial context, conflicting objectives, brittle handoffs.
- Mitigations: role tiering, explicit endings, pointer discipline, receipt-first outputs.

## Role tiering (planner / worker / judge)
- Planner: sets goal + constraints + stop conditions.
- Worker: executes smallest reversible mutation.
- Judge: verifies receipts; approves “past tense” only after validation.

## Planned endings
- Every wave emits: WAVE_END: <name> UTC=<ts> SESSION=<label>
- Stop on diminishing returns; rotate sessions on bloat/lag/policy risk.

## Progressive disclosure of tool-sets
- Default minimal tools; escalate only when bounded + reversible.
- Prefer templated DO blocks over prose.
- Tool-count limits: avoid “agent sprawl” unless ROI is proven.

## Externalized state as source-of-truth
- Treat session identity as DATA, not inferred.
- Prefer repo artifacts + hashes over “chat says so”.
- Prefer FULL-URL pointers (RAW) to canon artifacts.

## SOURCES pointers (FULL URLs only)
- (fill when canonical repo pointer exists / when telemetry is classified)

