---
coterm: CoSourceID
aliases: [CoSource-ID, SourceID, CoSID]
category: [Identity, Provenance, Audit, AntiCapture]
status: living
stability: medium
owner: CoCivium
last_reviewed_utc: 2026-01-29T00:00:00Z
crossrefs: [GIBindex, CoBeacon, CoBus, CoRails, CoAudit, CoShare, CoHalo]
---

# CoSourceID

## 1-liner
**CoSourceID** is an externally-defined, auditable identity + provenance substrate for sessions, repos, artifacts, and canonical pointers—verifiable without trusting any single platform, session, or vendor.

## What it is
A portable identity record binding:
- **canonical identity** (what it is),
- **issuer** (who/what asserts it),
- **evidence** (RAW URL + sha256 receipts),
- **rotation/revocation** (how identity changes safely).

## Why it exists
Identity mistakes compound under orchestration pressure:
- PowerShell variable name case-insensitivity encourages drift.
- Session bloat + parallel sessions amplify “same label, different thing.”
- Repo transfers/renames break UI URLs.
- Branch-based RAW pointers can 404 or mutate.
CoSourceID mitigates capture by forcing **portable canonical IDs + verifiable evidence**.

## Required fields
- canonical_id
- aliases
- issuer
- evidence (RAW+sha256; prefer immutable commit-SHA)
- rotation
- revocation

## CoMetaTrain
### CoCTA
- Require CoSourceID record for every authority pointer file (CoBeacon/rails/MasterPlan pointer).
- Enforce validator: canonical pointer must include at least one immutable evidence receipt.

### CoBlastRadius
High: bad identity propagates into publish surfaces, audits, and IP leakage.

### CoVersion / CoEvo
v0 schema; v1 validation+build; v2 optional signatures/key rotation.

### CoChangeLog
Record schema changes + migrations.

### CoRef
CoBeacon RAW pointers + CoBus rails (once canon destinations provided).

### CoUseCases
Canonical pointer files include CoSourceID evidence block; handoffs reference canonical_id, not labels alone.

### CoAntiPatterns
Trusting UI URL alone; branch-RAW as canonical; “see above”; label drift.

### CoGuardrails
Don’t publish vault paths; treat crown-jewel evidence per disclosure rules.

### CoIP
Schema likely publishable; real evidence receipts may be sensitive.

### CoAuditHooks
PASS requires canonical_id + evidence(raw_url+sha256) + rotation/revocation.