# CoHalo + CoFeed — rickpublic corpus → onboarding/RepTag + aligned feed curation (v0.6)

_Date (UTC):_ 2026-02-04 15:10:54Z  
_Status:_ **draft-ready** (designed to be pasted into CoHalo/CoPrime planning; replace with corpus ZIP excerpts when available)

---

## 0) What you’re getting (why this is worth shipping)

This is a **productization pack** that turns the rickpublic Substack thesis (e.g., “YouNow → YouNext” CivShifts) into:

1) **CoHalo onboarding** primitives (sliders, oaths, friction rules, RepTags)  
2) A standalone, viral “free-to-world” product concept: **CoFeed** (aligned feed curation + vetting), with a realistic path to monetization.

This document is written to be **drop‑in usable** by a CoHalo session and also legible to CoPrime for MasterPlan insertion.

---

## 1) CoFeed in one page

**CoFeed** = “Your feed, but with a spine.”

A lightweight layer that sits between content sources (RSS, Substack, newsletters, social, docs) and the user’s own AI, so that:

- the user defines **alignment preferences** (via CoHalo’s sliders / scales),
- CoFeed applies **transparent rating criteria** to each item,
- and the user’s AI generates a *small, actionable digest* instead of an outrage buffet.

### The core promise
- **Less noise, more signal.**
- **Less recruiting, more thinking.**
- **Less “what should I believe?”, more “what should I test?”**

### A simple mental model
Input stream → (Filter + Rate + Summarize) → Output stream

- Filter reduces volume.
- Rate explains *why* something is being recommended or downranked.
- Summarize produces “least work” consumption.

---

## 2) Why this is monetizable (without becoming the thing we hate)

A business model is viable because **attention + trust** are now scarce, and most curation products optimize for *engagement*, not *sanity*.

**Open / viral tier (free):**
- personal alignment sliders
- daily/weekly “CoFeed digest”
- basic “reasoned rating” and “disagree modes”

**Paid tiers (individual):**
- deeper “prompt stacks” (more criteria, more explainability)
- personal “trigger detection” (money/status/conflict/news/etc.)
- “anti‑recruitment mode” (guards against rage-bait amplification)

**Paid tiers (teams/orgs):**
- shared alignment profile (team norms)
- audit logs (why content was promoted/demoted)
- source allowlists + policy locks
- deliverables with citations (market intel style)

This pattern is already validated by incumbents that sell **AI-assisted reading and market intelligence** (see sources in Section 7).

---

## 3) CoHalo integration: the bridge that makes CoFeed work

CoFeed only becomes “CoCivium-grade” when it’s driven by **explicit user intention**.

CoHalo supplies:
- **profile axes** (sliders)
- **RepTags** (compact “who this user is” tokens)
- **allowance logic** (how much friction CoCivium applies)

CoFeed consumes:
- RepTags + slider positions
- a small set of “rules to live by” / oaths
- “do not amplify” thresholds

### Minimal CoHalo onboarding (60 seconds)
- 7 sliders + 1 oath:
  - “I can revise without needing an enemy.” (Yes / Not yet)

### RepTag examples (compact and queryable)
- `civshift.tribe_method=3/4`
- `civshift.emotion_evidence=2/4`
- `conflict.style=repair_over_win`
- `ai.use=amplifier_not_idol`
- `revision.public_shame_resistance=high`

---

## 4) The CivShift axes as user-settable preferences (the “scales”)

Make the arrows **scales** (not commandments).  
Users choose where they want to sit, and CoCivium chooses what it can safely tolerate.

Use fixed-width alignment so the arrow visually “clicks”:

```
YouNow → YouNext
Tribe      → Method
Emotion    → Evidence
Roles      → Consent
Status     → Meaning
Stuff      → Optionality
Contracts  → Renewal
Safety     → Managed Risk
```

### Slider semantics (0–4)
0 = legacy default  
1 = legacy-leaning  
2 = mixed / transitional  
3 = modern-leaning  
4 = YouNext-leaning

CoFeed then uses these values as weights for ranking:
- **higher Method/Evidence** → more weight on sources, citations, falsifiability
- **higher Consent/Renewal** → more weight on agency + reversible commitments
- **higher Optionality/Managed Risk** → more tolerance for uncertainty + experiments

---

## 5) CoFeed scoring model (simple, non-icon, least drama)

**Do not show “scores” first.** Show reasons first; scores second.

### Two orthogonal ratings per item

**A) Signal value** (how useful is this for your goals?)
- Low / Medium / High

**B) Mindshare hazard** (how likely is this to recruit you into nonsense?)
- None / Mild / Serious / Severe / Extreme

These are not moral judgments; they are operational labels.

### Example “why” output (the point is the explanation)
- “High signal because it contains primary data + counterarguments; Mild hazard.”
- “Low signal because it’s speculation without methods; Severe hazard due to outrage framing + identity hooks.”

---

## 6) Architecture (practical, not sci-fi)

### Reference implementation options

**Option 1: Local-first (recommended for trust)**
- RSS reader + local database
- local rules engine
- local LLM (or user’s chosen provider)
- output: digest + tagged feed

**Option 2: Cloud proxy (easier onboarding)**
- CoFeed proxy ingests feeds
- stores only metadata + hashes by default
- user opts-in to store full text
- output: email digest + app feed

**Option 3: “Bring-your-own-AI” plugin**
- CoFeed ships prompt packs + scoring rubrics
- the user runs them in their AI client
- CoFeed becomes a standards layer (portable)

### The non-negotiable design constraint
Feed content is **untrusted input**.

If the system ever allows untrusted content to steer privileged actions, you must assume it can be exploited.

---

## 7) Competitive context (what exists now, and what we do differently)

Existing products already do AI-assisted reading, filtering, summarization, and market intel; we should treat them as proof of demand, not threats.

- **Feedly** positions “Ask AI” for market intelligence; it emphasizes synthesis from multiple articles and generating deliverables with citations.  
- **Inoreader** and other RSS tools offer strong filtering/rules; some have AI features.  
- **Readwise Reader** and similar tools focus on “read later,” highlights, and knowledge workflows.  
- **Bulletin** (post-Artifact era) is an example of AI summaries + clickbait cleanup in a reader-style UX.  
- **NewsGuard** and **Ground News** show “trust labels / bias views” as UX patterns people already understand.

**CoFeed differentiation:**
- It doesn’t optimize for engagement; it optimizes for **revision capacity**.
- It treats “recruitment content” as a hazard class.
- It is driven by **user-declared alignment** (CoHalo scales), not hidden algorithms.

_Sources are listed in the References section._

---

## 8) Trust & safety: prompt injection, manipulation, and “feed poisoning”

If you ship CoFeed, you are building a retrieval + summarization pipeline.  
This introduces a security class: **prompt injection / indirect instruction attacks**, where untrusted content attempts to control the model.

High-level best practice (aligned with NCSC guidance):
- Treat LLMs as **inherently confusable**: they don’t reliably separate “data” from “instructions.”
- Assume you cannot “patch it away”; you can only **reduce impact** through architecture (least privilege, isolation, logging, deterministic guards).  

This matters for CoFeed because attackers can try to:
- poison the feed to push agendas,
- inject instructions into scraped content,
- trick the system into leaking user data,
- or manipulate ranking.

Mitigation shape:
- keep tools/privileges minimal when processing untrusted text
- separate stages (fetch → parse → rate → summarize) with strict contracts
- log reasons for promotions/demotions
- allow user to inspect sources and override

---

## 9) How this folds back into CoCivium (the bigger bet)

CoFeed is a distribution layer for CoCivium because it makes “mindshare hygiene” **practical**.

If CoCivium is a mindshare future:
- the scarce asset is not content,
- it’s **the transfer function**: moving meaning between minds without turning it into war.

CoFeed trains that function via:
- explicit criteria,
- revision rituals,
- and anti-recruitment defaults.

---

## 10) Appendix A — “least work” CTA patterns (what readers actually do)

If you want comments (not applause), reduce work.

Use this as a comment prompt block:

- “The line I reject is: ___. Here’s why: ___. Better rewrite: ___.”
- “The CivShift I resist most is: ___. The cost of adopting it is: ___. The cost of not adopting it is: ___.”
- “This is naive about power at: ___. Here’s a counterexample: ___.”
- “This feels like recruiting here: ___. Rewrite it without an enemy: ___.”

---

## 11) Appendix B — Substack corpus visibility (how to make your posts readable to tools)

If you want me (or CoHalo tooling) to read the whole corpus reliably, **export is best**.

### A) RSS feed (quick)
Substack states your publication RSS feed is:
`https://your.substack.com/feed` (replace `your`).  
For rickpublic: `https://rickpublic.substack.com/feed`

### B) Export ZIP (best)
Substack supports exporting your data (posts + subscriber list) from settings; the export is delivered as a ZIP (often via email).  
A well-known public walkthrough describes “Settings → Export your data → Create New Export,” then download the ZIP when ready.  
(See references.)

### C) If the UI is confusing
Use the Posts archive + a local extractor:
- A Chrome extension exists that exports Substack post titles + links from the Archive page to CSV.  
This is a stopgap, but useful for indexing.

---

## References (public web)

- Feedly: “New Feedly Ask AI: from information overload to actionable insights” (Mar 12, 2025) — https://feedly.com/new-features/posts/new-feedly-ask-ai-from-information-overload-to-actionable-insights
- Feedly docs: AI Feeds / AI Models aliasing — https://docs.feedly.com/article/516-where-can-i-see-the-list-of-aliases-for-my-leo-web-alerts-ai-models
- TechCrunch: Bulletin AI news reader (Feb 15, 2024) — https://techcrunch.com/2024/02/15/bulletin-is-a-new-ai-powered-news-reader-that-tackles-clickbait-and-summaries-stories/
- UK NCSC: “Prompt injection is not SQL injection (it may be worse)” (PDF) — https://www.ncsc.gov.uk/pdfs/blog-post/prompt-injection-is-not-sql-injection.pdf
- OWASP: Top risks for LLM / genAI apps (prompt injection referenced as leading risk) — https://owasp.org
- NewsGuard overview — https://www.newsguardtech.com
- Ground News overview (Blindspot/bias comparison) — https://ground.news
- Substack support: RSS feed for publication — https://support.substack.com/hc/en-us/articles/360038239391-Is-there-an-RSS-feed-for-my-publication
- Wired: exporting Substack data (migration guide includes “Export Your Data / ZIP”) — https://www.wired.com/story/how-to-migrate-newsletter-substack-to-buttondown/
- Chrome extension: “Substack Posts Organiser” — https://chromewebstore.google.com/detail/substack-posts-organiser/ijcjhnchchbhdijoeemnddpojicgmckh

---


---

## 12) Appendix C — Turning rickpublic into a corpus CoHalo/CoFeed can actually use

CoHalo and CoFeed will work better when the corpus is indexed as **(title, date, url, tags, excerpt)**.

Here are three ways to generate that, in order of reliability:

### C1) Best: Substack export ZIP (publisher-side)
- Go to your publication dashboard → **Settings**
- Find **Import/Export** or the “Export your data” section (location varies by UI).
- Create a new export; download the ZIP when Substack emails it.
- The ZIP typically contains:
  - an “email_list*.csv” (subscribers)
  - a posts archive folder / file(s) containing post content and metadata

If the export UI is missing or inconsistent, a migration guide and Buttondown’s import docs describe the export ZIP workflow and where Substack places Import/Export settings.  
(See references in Section 11 of this doc.)

### C2) Medium: Archive-page CSV (fast indexing)
- Open your archive page: `https://rickpublic.substack.com/archive`
- Use a local-only Chrome extension that exports titles + links to CSV.
- This creates a clean index quickly (then CoFeed can fetch full text per URL).

### C3) Quick: RSS feed (may be truncated)
- Substack’s official publication RSS is: `https://rickpublic.substack.com/feed`
- Some RSS feeds include only recent posts; treat RSS as “latest slice”, not full backup.

### Output format we want (drop-in to CoHalo tooling)
CSV columns:
- `published_at_utc,title,url,topic_guess,claims,call_to_action,rep_tags_suggested`

AIs can fill the last 4 columns automatically once the first 3 exist.

---

## 13) Appendix D — Prior pack receipts and “do-not-drop” highlights

These are the two earlier packs you downloaded, preserved as receipts.

- `CoHalo_Substack_SynthesisPack_rickpublic_v0_3.md`  
  SHA256: `f333367d362962df04ea896985b5bf1e3ef825e80290f8349353d5403b283ef7`

- `CoHalo_rickpublic_Corpus_to_CoHalo_RepTag_Pack_v0_4.md`  
  SHA256: `20d93bcb0ba78cd3d0875d27a559f8b2fc45e45956d0e95d04e909e4c7639477`  
  Note: this one is intentionally lightweight / partially-blocked due to feed fetch instability at the time.

### What should never be dropped (from v0.3)
- Treat “YouNow → YouNext” as **scales**, not commandments.
- Build onboarding as:
  - short hooks → scales → examples → “mirror” checkboxes → share/CTA.
- RepTag primitives:
  - `civshift.*` vector plus “revision without enemy” as a first-class signal.
- Use “least-work” comment prompts to solicit *disagreement*, not applause.

(Full text retained in v0.3 file; keep it as canon input.)

---

## 14) Appendix E — CoHalo/CoPrime handoff snippet (copy/paste)

**Intent:** Add CoFeed (aligned feed curation) as a bridge product: CoHalo onboarding → RepTags → CoFeed digest.  
**Input corpus:** rickpublic Substack posts (use export ZIP or archive CSV).  
**Core scales:** Tribe→Method, Emotion→Evidence, Roles→Consent, Status→Meaning, Stuff→Optionality, Contracts→Renewal, Safety→Managed Risk.  
**Value prop:** reduce recruitment content, increase revision capacity, produce explainable digests.

---

_End of addenda._


_End._
