# CoHalo / RepTag / CoFeed — Identity + Alignment + Reputation — Advisory Pack v0.5
_Date (UTC):_ 2026-02-04 15:26:00Z

> **Intent:** Consolidate the “YouNow → YouNext / CivShifts” thesis into **product-grade** onboarding axes (RepTags), then extend it into a **privacy-preserving identity & reputation presentation layer** (CoHalo pages) and an optional **feed curation layer** (CoFeed) that can be launched free/viral and monetized later.

---

## 0) Executive snapshot (what to ship first)
**Soft-launch (XR/gaming) priority:** keep it *simple, pseudonymous, and fun*.

1. **CoHalo v0 (Onboarding + RepTags):** 7 axes (sliders) + 12-item “Mirror” ticklist → generates RepTag bundle + one shareable line.
2. **CoHalo Page v0 (Public proof without dox):** a public profile page keyed by a pseudonymous handle, showing only what the user chooses.
3. **CoFeed v0 (Bring-your-own-feeds):** a browser extension / app workflow that scores an RSS/news/social feed using the user’s RepTag preferences; outputs “why” explanations and a “rewrite-me” prompt for the user’s own AI.

Everything else (credentials, anti-sybil, cross-platform reputation) can be layered in later without breaking v0.

---

## 1) Key problem framing (why this matters)
You’re mixing three problems that *look* similar but must be separated or you’ll blow up trust:

### A) Alignment tracking (preferences + values)
- “How do you want to think and act in Civ2?”
- Output: **RepTags**, preference profiles, onboarding affordances.

### B) Reputation tracking (behavioral history, trust signals)
- “What evidence exists that you act that way?”
- Output: **attestations**, receipts, references, scores with provenance.

### C) Identity management (who is making the claim)
- “How do we know one entity controls these accounts, without forcing dox?”
- Output: **proof-of-control**, optional identity proofing tiers.

**Design rule:** alignment is self-declared; reputation is evidence-backed; identity is proof-of-control. Do **not** collapse these.

---

## 2) The 7 CivShifts as product axes (RepTag backbone)
### 2.1 Display format (aligned + scannable)
Use this exact 7-line format in UI, docs, and onboarding. Keep it consistent everywhere.

```
YouNow      → YouNext
Tribe       → Method
Emotion     → Evidence
Roles       → Consent
Status      → Meaning
Stuff       → Optionality
Contracts   → Renewal
Safety      → Managed Risk
```

### 2.2 How to turn each axis into a slider
Each axis is a **spectrum**, not a doctrine. CoHalo should let users place themselves and optionally choose a *target drift* (where they want to evolve).

- **Slider**: 0–4 (or 0–7) with plain-language anchors.
- **Two values per axis**:
  - **Current** (self-assessment)
  - **Aim** (where they want help drifting)

Example per axis:
- Current: “I still rely on tribe”
- Aim: “I want to rely on method”

### 2.3 RepTag encoding (compact + queryable)
Keep this minimal; you want tags that fit in URLs, QR codes, and short strings.

- TM0–TM4 = Tribe→Method
- EE0–EE4 = Emotion→Evidence
- RC0–RC4 = Roles→Consent
- SM0–SM4 = Status→Meaning
- SO0–SO4 = Stuff→Optionality
- CR0–CR4 = Contracts→Renewal
- SR0–SR4 = Safety→Managed Risk

Example bundle:
`TM3 EE2 RC4 SM1 SO3 CR2 SR2`

**Routing use:** CoCivium can adapt prompts, defaults, and guardrails using the bundle.

---

## 3) CoHalo Page: presentation layer that drives pride without dox
### 3.1 What the page must do (viral + safe)
A CoHalo page should make a user feel:
- “I’m proud of my internet footprint.”
- “I can prove I’m real and accountable without surrendering my privacy.”
- “I can evolve my profile over time without it becoming a permanent scar.”

### 3.2 Public vs private fields (non-negotiable separation)
**Public (default minimal):**
- Chosen display name + avatar
- RepTag bundle (or just a “summary signature”)
- Mirror score band (“Spark / Scout / Builder / Steward”)
- Proof-of-control badges (optional; see below)
- “Last updated” timestamp
- One shareable “line to keep” (user-chosen)

**Private (always private unless explicitly disclosed):**
- Raw tickbox answers
- Detailed feed inputs, browsing history, AI logs
- Cross-platform identifiers the user hasn’t disclosed
- Any KYC / legal identity proofing artifacts

### 3.3 Proof-of-control without doxing (v0 → v2)
**v0 (fast):** user claims handles; no verification.
- Good for soft launch; low friction; low trust.

**v1 (proof-of-control):** verify account control without revealing more.
- Pattern: user posts a short challenge code (or signs in via OAuth) to prove control of:
  - GitHub, X, Discord, Reddit, Substack, etc.

**v2 (attestations):** community-issued claims.
- “This user is a good-faith contributor” signed by a moderator/DAO/club.

### 3.4 Why “self-doxing” is dangerous (and how to route it)
If CoHalo lets users dox themselves freely, two things happen:
1. The platform becomes a target for coercion and harassment.
2. You collapse “reputation” into “identity politics,” which destroys the method-first ethos.

**Recommendation:** allow dox only via **external** link-out (user-controlled) and treat it as a separate decision with a warning panel.

---

## 4) Identity & trust architecture (edge-balanced, not core-controlled)
### 4.1 Authentication (practical, not fancy)
For consumer-grade onboarding, use **passkeys / WebAuthn** as the primary authentication; it’s phishing-resistant and low friction.

- User logs in with a passkey.
- They can add recovery factors later.

(Reference: W3C WebAuthn / passkey ecosystem.)

### 4.2 Portable identifiers (future-proofing)
Long-term, consider using open standards for portable identity claims:
- **DIDs** (Decentralized Identifiers) for identifier portability.
- **Verifiable Credentials (VCs)** for attestations (selective disclosure).

These give you a path to:
- multiple IDs per user,
- selective disclosure,
- proofs that don’t require dox.

### 4.3 Privacy-preserving proof tokens (anti-bot, anti-sybil-ish)
For “are you a human?” gating, consider **Privacy Pass** style tokens (anonymous, unlinkable) as one layer.
Do not pretend this solves Sybil attacks alone; it just makes spam harder.

### 4.4 Sybil resistance: pick the right defense for the stage
For XR soft launch, you likely need **light** defenses:
- invite links + rate limits,
- proof-of-control of at least one external account,
- community moderation.

Hard defenses (social graph Sybil defense, proof-of-personhood) can come later if abuse forces it.

---

## 5) CoFeed: “aligned feed evolution” as a standalone viral product
### 5.1 What CoFeed is (in one sentence)
**CoFeed** is a lens that scores and reshapes what you consume using your RepTags (alignment preferences) so your own AI can help you evolve *without outsourcing your values*.

### 5.2 Why it can be monetizable later
AI makes content infinite; attention becomes the scarce resource.
People will pay for:
- “less rage, more signal”
- “why this is being shown”
- “how to update without enemies”
- portable preference profiles (RepTags) across apps

### 5.3 CoFeed v0: simplest possible MVP
Ship it as **one of these** (pick the least engineering):
1. **Browser extension**: takes a page/feed and runs a scoring prompt + explanation.
2. **RSS hub**: user pastes RSS URLs; CoFeed ranks & summarizes.
3. **Email forwarder**: user forwards links; CoFeed replies with “score + why + rewrite.”

### 5.4 CoFeed scoring rubric (powered by the 7 axes)
For each item, output:
- **Axis pressure**: which CivShift it tries to drag you toward (tribe, outrage, status, etc.)
- **Evidence density**: how falsifiable it is
- **Recruitment smell**: “are you being recruited?”
- **Rewrite suggestion**: a method-first prompt to reframe the claim

### 5.5 Competitive context (what exists today)
The market already shows demand for “filtering and trust layers”:
- Feed readers with AI filtering/summarization (e.g., Feedly, Inoreader)
- Bias/coverage tools (e.g., Ground News)

Your wedge is **alignment + self-evolution**, not “more content.”

---

## 6) Roadmap: align with Master Plan (soft launch now, heavy identity later)
### Phase 0 — XR/gaming soft launch (weeks)
- RepTags + Mirror score
- CoHalo page (pseudonymous)
- CoFeed v0 (browser/RSS/email)

### Phase 1 — Proof-of-control + moderation (months)
- Account verification flows
- Moderator attestations
- Basic anti-spam tokens

### Phase 2 — Portable credentials (later)
- DIDs + VCs
- Selective disclosure proofs
- Optional regulated identity proofing tiers

---

## 7) How the “View From Future You” article maps into CoHalo product
### 7.1 Use the article as:
- onboarding copy (hook + vibe)
- axis definitions (the 7 shifts)
- micro-prompts (“recruiting vs thinking”)
- “Mirror” as a recurring self-check
- shareable one-liners for virality

### 7.2 Turn each shift into:
- one slider question
- one “why letting go is hard” paragraph
- one “picture this” vignette
- 3–5 “Before → After” rewrites

That’s enough to build the user’s **CoHalo page content** automatically.

---

## 8) Appendix A — Comment Fuel (CTA engine)
**Purpose:** Reduce reader effort and invite *specific* disagreement.

Pick one, fill blanks, post publicly:

1. “The strongest counterexample to ‘scale turns comfort into damage’ is: ____.”
2. “The shift I reject most is ____ because ____.”
3. “This piece ignores power here: ____.”
4. “This piece overstates AI here: ____.”
5. “This piece understates tradition here: ____.”
6. “A line that reads like recruitment is: ‘____’. Rewrite it as: ‘____’.”
7. “The claim that fails in my lived reality is: ____.”
8. “The hidden assumption I think you’re making is: ____.”
9. “The thing you’re moralizing about without admitting it is: ____.”
10. “If I accepted your thesis, the first hard tradeoff would be: ____.”

---

## 9) Appendix B — Substack visibility + backup (practical)
### 9.1 Substack’s built-in exports (what exists)
- You can export your **subscriber list** as CSV from the Subscribers dashboard.
- There are also platform-wide “export your data” flows referenced by migration guides, and third-party tools exist for exporting post archives.

(See references list for official support docs + one migration guide.)

### 9.2 Making your Substack corpus “visible” to an AI assistant
Fastest options:
1. **RSS feed URL** (best for automation; might be truncated depending on platform policies).
2. **Export ZIP** (posts + metadata) and upload it here as a file.
3. **Manual: archive page export** (CSV of titles+links), then fetch the pages.

If you can’t find the export UI, the official docs below show where Substack places Export in the Subscribers dashboard.

---

## 10) References (primary sources + why they matter)
> These links are placed in-file so you can paste them into CoPrime/CoHalo docs and so future sessions can re-check them.

### Identity, credentials, authentication (primary)
- NIST SP 800-63-3 (Digital Identity Guidelines): https://pages.nist.gov/800-63-3/
- W3C DID Core 1.0: https://www.w3.org/TR/did-core/
- W3C Verifiable Credentials Data Model 2.0: https://www.w3.org/TR/vc-data-model-2.0/
- OpenID4VP 1.0: https://openid.net/specs/openid-4-verifiable-presentations-1_0.html
- OpenID4VCI 1.0: https://openid.net/specs/openid-4-verifiable-credential-issuance-1_0.html
- W3C WebAuthn Level 2: https://www.w3.org/TR/webauthn-2/
- Privacy Pass (RFC 9577/9578): https://www.rfc-editor.org/rfc/rfc9577 ; https://www.rfc-editor.org/rfc/rfc9578

### Feed curation competitive context (examples)
- Feedly (AI features): https://feedly.com/ai
- Inoreader (automation/rules): https://www.inoreader.com/
- Ground News (how it works): https://ground.news/how

### Substack export/backup (official + practical)
- Substack support: import/export & migrating guides: https://support.substack.com/hc/en-us/articles/34558456517396-How-do-I-move-from-my-current-platform-to-Substack
- Substack support: importing posts (includes Import/Export settings path): https://support.substack.com/hc/en-us/articles/360037830351-How-do-I-import-my-posts-from-another-platform-such-as-Mailchimp-WordPress-Medium-or-Ghost
- Subscriber dashboard guide (export CSV mention): https://on.substack.com/p/subscriber-dashboard-guide
- Migration away from Substack (mentions “Export Your Data” ZIP in Substack UI): https://www.wired.com/story/how-to-migrate-newsletter-substack-to-buttondown/

---

## 11) What to paste into CoHalo/CoPrime (ready-made note snippet)
**Recommended:** paste this into CoHalo as a “Roadmap + Architecture” seed:

- CoHalo separates (A) Alignment (RepTags) vs (B) Reputation (attestations) vs (C) Identity (proof-of-control).
- v0 ships 7 CivShift sliders + Mirror ticks → RepTag bundle + CoHalo page (pseudonymous).
- v1 adds proof-of-control badges; v2 adds community attestations; later add DIDs/VCs for portability + selective disclosure.
- CoFeed is a viral wedge: user’s RepTags drive feed scoring + explanations + rewrite prompts; monetize later via premium packs.

